#ifndef __managment_bracket__
#define __managment_bracket__
int alphabet();
int bracket_managment();
void  operarion_order_run();
float number_computation();
void order(char operato, char *suite);
int order_multi_divise(char *suite);
void gotoxy(int x, int y);
void rectangle(int x, int y, int l, int h);
void rextange_rectangle(int g);
void saisir(char suite[256]);

#endif // __managment_bracket__
